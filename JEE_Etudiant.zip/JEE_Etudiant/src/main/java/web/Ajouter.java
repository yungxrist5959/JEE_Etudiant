package web;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Ajouter extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        if (session.getAttribute("login") != null) {
            String nom = request.getParameter("nom");
            String date = request.getParameter("date");
            String sexe = request.getParameter("sexe");
            String classe = request.getParameter("classe");
            
            String url  = "jdbc:mysql://localhost:3306/JEE_Etudiant";
            String user = "root";
            String pwd  = "";
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection(url, user, pwd);
                PreparedStatement pst = con.prepareStatement("INSERT INTO etudiant (nom, date_ins, sexe , classe) VALUES (? , ? , ? , ?)");
                pst.setString(1, nom);
                pst.setString(2, date);
                pst.setString(3, sexe);
                pst.setString(4, classe);
                pst.executeUpdate();
                response.sendRedirect("index.jsp");
                pst.close();
                con.close();
            } catch (Exception e) {
                e.printStackTrace(); 
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Une erreur est survenue lors de l'ajout de l'étudiant.");
            }
        } else {
            response.sendRedirect("Auth.jsp");
        }
    }
}