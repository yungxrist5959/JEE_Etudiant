package web;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class Modification extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        if (session.getAttribute("login") != null) {
            String id = request.getParameter("id");
            String nom = request.getParameter("nom");
            String date = request.getParameter("date");
            String sexe = request.getParameter("sexe");
            String classe = request.getParameter("classe");


            String url  = "jdbc:mysql://localhost:3306/JEE_Etudiant";
            String user = "root";
            String pwd  = "";
            Connection con = null;
            PreparedStatement pst = null;
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection(url, user, pwd);
                pst = con.prepareStatement("UPDATE etudiant SET nom=?, date_ins=?, sexe=? , classe = ? WHERE id=?");
                pst.setString(1, nom);
                pst.setString(2, date);
                pst.setString(3, sexe);
                pst.setString(4, classe);
                pst.setString(5, id);
                


                int rowsUpdated = pst.executeUpdate();
                if (rowsUpdated > 0) {
                    response.sendRedirect("index.jsp");
                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "Aucune ligne n'a été modifiée dans la base de données.");
                }
            } catch (Exception e) {
                e.printStackTrace();
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Une erreur est survenue lors de la modification de l'étudiant.");
            } finally {
                try {
                    if (pst != null) pst.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } else {
            response.sendRedirect("Auth.jsp");
        }
    }
}
